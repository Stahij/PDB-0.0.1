# PDB MVP. Add keep rules only when release shrinking is enabled.
