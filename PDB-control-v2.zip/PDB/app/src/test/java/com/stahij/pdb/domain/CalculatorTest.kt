package com.stahij.pdb.domain
import com.stahij.pdb.data.Seed
import org.junit.Assert.*
import org.junit.Test
class CalculatorTest { private val c=Calculator(); private val vodka=Ingredient(100,"Vodka",IngredientType.SPIRIT,40.0,0xFFFFFFFFu.toLong(),0.0,0.0,0.0); private val juice=Ingredient(101,"Juice",IngredientType.JUICE,0.0,0xFFFFAA00u.toLong(),6.0,3.0,0.0); private val ice=Ingredient(102,"Ice",IngredientType.ICE,0.0,0xFFDDF4FFu.toLong(),0.0,0.0,0.0)
@Test fun emptyIsSafe(){assertEquals(0.0,c(emptyList(),0.0).abv,0.0)}
@Test fun abvIsWeighted(){assertEquals(20.0,c(listOf(Portion(vodka,50.0),Portion(juice,50.0)),0.0).abv,.001)}
@Test fun garnishIgnored(){assertEquals(40.0,c(listOf(Portion(vodka,50.0),Portion(juice,200.0,IngredientRole.GARNISH)),0.0).abv,.001)}
@Test fun iceDilutesWhenMelted(){val dry=c(listOf(Portion(vodka,50.0),Portion(ice,100.0)),0.0);val wet=c(listOf(Portion(vodka,50.0),Portion(ice,100.0)),1.0);assertTrue(wet.abv<dry.abv);assertTrue(wet.liquidMl>dry.liquidMl)}
@Test fun seedHasValidUniqueIds(){assertEquals(Seed.ingredients.size,Seed.ingredients.map{it.id}.toSet().size);assertTrue(Seed.ingredients.all{it.abv in 0.0..100.0&&it.sweetness in 0.0..10.0&&it.sourness in 0.0..10.0&&it.bitterness in 0.0..10.0})}
}
