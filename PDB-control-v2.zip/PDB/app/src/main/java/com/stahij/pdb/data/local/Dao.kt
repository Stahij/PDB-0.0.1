package com.stahij.pdb.data.local

import android.room3.Dao
import android.room3.Insert
import android.room3.OnConflictStrategy
import android.room3.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface IngredientDao {
    @Query("SELECT * FROM ingredients ORDER BY type, name")
    fun observeAll(): Flow<List<IngredientEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<IngredientEntity>)
    @Query("SELECT COUNT(*) FROM ingredients")
    suspend fun count(): Int
}

@Dao
interface RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<RecipeEntity>>
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertRecipe(item: RecipeEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPortions(items: List<RecipePortionEntity>)
}
