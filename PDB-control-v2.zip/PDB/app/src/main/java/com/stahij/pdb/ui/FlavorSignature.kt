package com.stahij.pdb.ui
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.stahij.pdb.R
import com.stahij.pdb.domain.CocktailResult
import kotlin.math.*
@Composable fun FlavorSignature(r:CocktailResult,modifier:Modifier=Modifier){val description=stringResource(R.string.flavor_signature_description);Box(modifier.semantics{contentDescription=description}){val t=tokens(LocalStyle.current);Canvas(Modifier.fillMaxSize()){val c=center;val rad=size.minDimension*.32f;val vals=listOf(r.sweetness,r.sourness,r.bitterness,r.strength).map{(it/10).toFloat()};repeat(3){i->drawCircle(t.muted.copy(alpha=.25f),rad*(i+1)/3,c,style=Stroke(1f))};val p=Path();vals.forEachIndexed{i,v->val a=-PI/2+i*PI/2;val q=Offset(c.x+cos(a).toFloat()*rad*v,c.y+sin(a).toFloat()*rad*v);if(i==0)p.moveTo(q.x,q.y)else p.lineTo(q.x,q.y)};p.close();drawPath(p,t.primary.copy(alpha=.28f));drawPath(p,t.accent,style=Stroke(3f))};Text(stringResource(R.string.sweetness),Modifier.align(Alignment.TopCenter));Text(stringResource(R.string.sourness),Modifier.align(Alignment.CenterEnd));Text(stringResource(R.string.bitterness),Modifier.align(Alignment.BottomCenter));Text(stringResource(R.string.strength),Modifier.align(Alignment.CenterStart))}}
