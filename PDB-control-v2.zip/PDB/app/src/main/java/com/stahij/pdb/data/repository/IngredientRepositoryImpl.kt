package com.stahij.pdb.data.repository

import com.stahij.pdb.data.local.IngredientDao
import com.stahij.pdb.domain.Ingredient
import com.stahij.pdb.domain.IngredientType
import com.stahij.pdb.domain.repository.IngredientRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class IngredientRepositoryImpl @Inject constructor(private val dao: IngredientDao) : IngredientRepository {
    override fun observeAll(): Flow<List<Ingredient>> = dao.observeAll().map { rows -> rows.map { row ->
        Ingredient(row.id, row.name, IngredientType.valueOf(row.type), row.abv, row.colorArgb, row.sweetness, row.sourness, row.bitterness, row.version)
    } }
}
