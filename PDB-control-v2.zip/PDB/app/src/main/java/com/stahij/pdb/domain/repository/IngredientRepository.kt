package com.stahij.pdb.domain.repository
import com.stahij.pdb.domain.Ingredient
import kotlinx.coroutines.flow.Flow
interface IngredientRepository { fun observeAll(): Flow<List<Ingredient>> }
