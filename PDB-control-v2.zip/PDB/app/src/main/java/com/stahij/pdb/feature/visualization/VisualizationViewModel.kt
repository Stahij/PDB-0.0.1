package com.stahij.pdb.feature.visualization
import androidx.lifecycle.ViewModel
import com.stahij.pdb.feature.builder.DraftStore
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
@HiltViewModel class VisualizationViewModel @Inject constructor(val store:DraftStore):ViewModel()
