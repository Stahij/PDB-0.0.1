package com.stahij.pdb
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.stahij.pdb.ui.*
import dagger.hilt.android.AndroidEntryPoint
@AndroidEntryPoint class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){ super.onCreate(b); enableEdgeToEdge(); setContent { PdbApp() } } }
