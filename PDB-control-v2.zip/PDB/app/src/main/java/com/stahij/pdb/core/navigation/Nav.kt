package com.stahij.pdb.core.navigation
import androidx.compose.runtime.Composable
import androidx.navigation.compose.*
import com.stahij.pdb.feature.builder.BuilderScreen
import com.stahij.pdb.feature.visualization.VisualizationScreen
@Composable fun AppNavHost(){val nav=rememberNavController();NavHost(nav,"builder"){composable("builder"){BuilderScreen{nav.navigate("visualization")}};composable("visualization"){VisualizationScreen{nav.popBackStack()}}}}
