package com.stahij.pdb.data.local

import android.room3.Entity
import android.room3.Index
import android.room3.PrimaryKey

@Entity(tableName = "ingredients", indices = [Index(value = ["name", "version"], unique = true)])
data class IngredientEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val type: String,
    val abv: Double,
    val colorArgb: Long,
    val sweetness: Double,
    val sourness: Double,
    val bitterness: Double,
    val version: Int,
)

@Entity(tableName = "recipes", indices = [Index(value = ["normalizedName"], unique = true)])
data class RecipeEntity(
    @PrimaryKey val id: String,
    val name: String,
    val normalizedName: String,
    val glassId: Long,
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(tableName = "recipe_portions", indices = [Index("recipeId"), Index("ingredientId")])
data class RecipePortionEntity(
    @PrimaryKey val id: String,
    val recipeId: String,
    val ingredientId: Long,
    val ingredientVersion: Int,
    val ml: Double?,
    val role: String,
    val sortOrder: Int,
)
