package com.stahij.pdb.feature.builder

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.stahij.pdb.R
import com.stahij.pdb.data.Seed
import com.stahij.pdb.domain.*
import com.stahij.pdb.ui.*
import kotlin.math.roundToInt

@Composable
fun BuilderScreen(onVisualize: () -> Unit, vm: BuilderViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val style = LocalStyle.current
    val setStyle = LocalSetStyle.current
    val t = tokens(style)
    Scaffold(containerColor = t.background) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("PDB", style = MaterialTheme.typography.headlineLarge)
                Text(stringResource(R.string.cocktail_creator), color = t.muted)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Style.entries.forEach { candidate -> FilterChip(candidate == style, { setStyle(candidate) }, { Text(candidate.name.replace('_',' ')) }) }
                }
            }
            item {
                Text(stringResource(R.string.choose_glass))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Seed.glasses.forEachIndexed { index, g -> FilterChip(index == state.glassIndex, { vm.setGlass(index) }, { Text("${g.name} ${g.capacityMl} ml") }) }
                }
            }
            item { OutlinedTextField(state.query, vm::setQuery, label={Text(stringResource(R.string.search_ingredient))}, modifier=Modifier.fillMaxWidth()) }
            items(state.ingredients, key={it.id}) { ing ->
                val portion = state.selected.firstOrNull{it.ingredient.id==ing.id&&it.role==IngredientRole.IN_DRINK}
                val ml = portion?.ml ?: 0.0
                val garnish = state.selected.any{it.ingredient.id==ing.id&&it.role==IngredientRole.GARNISH}
                Card { Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){Column{Text(ing.name);Text("${ing.type} · ${ing.abv}%",color=t.muted)};Text("${ml.roundToInt()} ml")}
                    Slider((ml/300.0).toFloat(), { v -> vm.setMl(ing, v.toDouble()*300.0) })
                    TextButton({vm.toggleGarnish(ing)}){Text(if(garnish) stringResource(R.string.remove_garnish) else stringResource(R.string.add_garnish))}
                }}
            }
            item { Text("${stringResource(R.string.ice_melt)} ${(state.melt*100).roundToInt()}%"); Slider(state.melt.toFloat(),{vm.setMelt(it.toDouble())}) }
            item { Card { Column(Modifier.padding(12.dp)) {
                Text("${stringResource(R.string.volume)} ${state.result.liquidMl.roundToInt()} ml")
                Text("ABV ${"%.1f".format(state.result.abv)}%")
                Text("${stringResource(R.string.occupied)} ${state.result.occupiedMl.roundToInt()} ml")
                if(state.overflowMl>0) Text("${stringResource(R.string.overflow)} +${state.overflowMl.roundToInt()} ml",color=MaterialTheme.colorScheme.error)
                FlavorSignature(state.result, Modifier.fillMaxWidth().height(190.dp))
            }} }
            item { Button({vm.draftStore.update(state);onVisualize()},Modifier.fillMaxWidth()){Text(stringResource(R.string.visualize))} }
        }
    }
}
