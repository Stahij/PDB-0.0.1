package com.stahij.pdb.feature.builder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.stahij.pdb.data.Seed
import com.stahij.pdb.domain.*
import com.stahij.pdb.domain.repository.IngredientRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class BuilderUiState(
    val ingredients: List<Ingredient> = emptyList(), val query: String = "", val selected: List<Portion> = emptyList(),
    val glassIndex: Int = 0, val melt: Double = 0.0, val result: CocktailResult = CocktailResult(), val overflowMl: Double = 0.0,
)
@HiltViewModel class BuilderViewModel @Inject constructor(repo: IngredientRepository, private val calculator: Calculator, val draftStore: DraftStore) : ViewModel() {
    private val query = MutableStateFlow(""); private val selected = MutableStateFlow<List<Portion>>(emptyList()); private val glass = MutableStateFlow(0); private val melt = MutableStateFlow(0.0)
    val state = combine(repo.observeAll(), query, selected, glass, melt) { all, q, lines, gi, mf ->
        val result = calculator(lines, mf); val filtered = all.filter { it.name.contains(q, true) }; val capacity = Seed.glasses[gi].capacityMl
        BuilderUiState(filtered, q, lines, gi, mf, result, (result.occupiedMl - capacity).coerceAtLeast(0.0))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BuilderUiState())
    fun setQuery(v:String){query.value=v}; fun setGlass(v:Int){glass.value=v}; fun setMelt(v:Double){melt.value=v.coerceIn(0.0,1.0)}
    fun setMl(i:Ingredient, ml:Double){selected.value=selected.value.filterNot{it.ingredient.id==i.id&&it.role==IngredientRole.IN_DRINK}+if(ml>0) listOf(Portion(i,ml.coerceAtLeast(0.0))) else emptyList()}
    fun toggleGarnish(i:Ingredient){val exists=selected.value.any{it.ingredient.id==i.id&&it.role==IngredientRole.GARNISH};selected.value=selected.value.filterNot{it.ingredient.id==i.id&&it.role==IngredientRole.GARNISH}+if(exists) emptyList() else listOf(Portion(i,0.0,IngredientRole.GARNISH))}
}
