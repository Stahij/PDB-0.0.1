package com.stahij.pdb.feature.builder
import com.stahij.pdb.data.Seed
import com.stahij.pdb.domain.*
import kotlinx.coroutines.flow.MutableStateFlow
import javax.inject.Inject
import javax.inject.Singleton
@Singleton class DraftStore @Inject constructor(){val draft=MutableStateFlow(CocktailDraft(Seed.glasses.first()));fun update(s:BuilderUiState){draft.value=CocktailDraft(Seed.glasses[s.glassIndex],s.selected,s.melt,s.result)}}
