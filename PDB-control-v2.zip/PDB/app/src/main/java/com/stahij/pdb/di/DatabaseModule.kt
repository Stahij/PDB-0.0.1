package com.stahij.pdb.di

import android.content.Context
import android.room3.Room
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import com.stahij.pdb.data.Seed
import com.stahij.pdb.data.local.*
import com.stahij.pdb.data.repository.IngredientRepositoryImpl
import com.stahij.pdb.domain.repository.IngredientRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.*
import javax.inject.Singleton

@Module @InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton fun database(@ApplicationContext context: Context): AppDatabase {
        val db = Room.databaseBuilder<AppDatabase>(context, "pdb.db")
            .setDriver(BundledSQLiteDriver())
            .setQueryCoroutineContext(Dispatchers.IO)
            .build()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            if (db.ingredientDao().count() == 0) db.ingredientDao().upsertAll(Seed.ingredients.map {
                IngredientEntity(it.id, it.name, it.type.name, it.abv, it.colorArgb, it.sweetness, it.sourness, it.bitterness, it.version)
            })
        }
        return db
    }
    @Provides fun ingredientDao(db: AppDatabase) = db.ingredientDao()
    @Provides fun recipeDao(db: AppDatabase) = db.recipeDao()
}
@Module @InstallIn(SingletonComponent::class)
abstract class RepositoryModule { @Binds abstract fun ingredients(impl: IngredientRepositoryImpl): IngredientRepository }
