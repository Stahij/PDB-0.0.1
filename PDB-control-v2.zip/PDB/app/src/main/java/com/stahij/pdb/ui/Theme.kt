package com.stahij.pdb.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

enum class Style { PREMIUM, NEO_LAB, SIGNATURE, PAPER_LAB }
data class Tokens(val background: Color, val surface: Color, val primary: Color, val accent: Color, val text: Color, val muted: Color, val sweetness: Color, val sourness: Color, val bitterness: Color, val strength: Color)
fun tokens(s: Style) = when (s) {
    Style.PREMIUM -> Tokens(Color(0xFF090B0E), Color(0xFF14191F), Color(0xFFFFB86B), Color(0xFFF3D37A), Color(0xFFF5F1EA), Color(0xFFA9B0B8), Color(0xFFF4C95D), Color(0xFF9ADB63), Color(0xFFF36E5A), Color(0xFF6DB7FF))
    Style.NEO_LAB -> Tokens(Color(0xFF070806), Color(0xFF11130F), Color(0xFFFFB23E), Color(0xFFFFD28A), Color(0xFFFFF7E8), Color(0xFFB6AA98), Color(0xFFEBC866), Color(0xFFA8D56A), Color(0xFFE15B42), Color(0xFFD0995B))
    Style.SIGNATURE -> Tokens(Color(0xFF06070A), Color(0xFF10141A), Color(0xFFB8FF46), Color(0xFF3FE4FF), Color(0xFFF7FAFF), Color(0xFF9EA6B6), Color(0xFFB8FF46), Color(0xFF54E8C3), Color(0xFFFF5E78), Color(0xFF916CFF))
    Style.PAPER_LAB -> Tokens(Color(0xFFE9E4DA), Color(0xFFF3EFE6), Color(0xFFB9F447), Color(0xFFFFA63B), Color(0xFF111210), Color(0xFF57584F), Color(0xFFE2B64A), Color(0xFF6B9E42), Color(0xFFC83C32), Color(0xFF3588A8))
}
val LocalStyle = staticCompositionLocalOf { Style.PREMIUM }
val LocalSetStyle = staticCompositionLocalOf<(Style) -> Unit> { {} }
@Composable fun PdbTheme(style: Style, content: @Composable () -> Unit) {
    val t = tokens(style)
    val scheme = if (style == Style.PAPER_LAB) lightColorScheme(primary=t.primary, background=t.background, surface=t.surface, onBackground=t.text, onSurface=t.text) else darkColorScheme(primary=t.primary, background=t.background, surface=t.surface, onBackground=t.text, onSurface=t.text)
    CompositionLocalProvider(LocalStyle provides style) { MaterialTheme(colorScheme = scheme, content = content) }
}
