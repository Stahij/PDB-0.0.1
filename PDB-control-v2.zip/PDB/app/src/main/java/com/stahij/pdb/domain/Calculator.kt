package com.stahij.pdb.domain

import javax.inject.Inject
import kotlin.math.roundToLong

class Calculator @Inject constructor() {
    operator fun invoke(lines: List<Portion>, meltFraction: Double): CocktailResult {
        val drink = lines.filter { it.role == IngredientRole.IN_DRINK && it.ml > 0.0 }
        val iceMl = drink.filter { it.ingredient.type == IngredientType.ICE }.sumOf { it.ml }
        val liquids = drink.filter { it.ingredient.type != IngredientType.ICE }
        val baseLiquidMl = liquids.sumOf { it.ml }
        val meltedWaterMl = iceMl * meltFraction.coerceIn(0.0, 1.0) * ICE_MELT_YIELD
        val totalLiquidMl = baseLiquidMl + meltedWaterMl
        val alcoholMl = liquids.sumOf { it.ml * it.ingredient.abv / 100.0 }
        val abv = if (totalLiquidMl == 0.0) 0.0 else alcoholMl / totalLiquidMl * 100.0

        fun profile(value: (Ingredient) -> Double): Double = if (totalLiquidMl == 0.0) 0.0 else
            (liquids.sumOf { it.ml * value(it.ingredient) } / totalLiquidMl).coerceIn(0.0, 10.0)

        val color = mixColor(liquids)
        return CocktailResult(
            liquidMl = totalLiquidMl,
            occupiedMl = baseLiquidMl + iceMl,
            abv = abv.coerceIn(0.0, 100.0),
            sweetness = profile { it.sweetness },
            sourness = profile { it.sourness },
            bitterness = profile { it.bitterness },
            strength = (abv / 4.0).coerceIn(0.0, 10.0),
            colorArgb = color,
        )
    }

    private fun mixColor(liquids: List<Portion>): Long {
        val volume = liquids.sumOf { it.ml }
        if (volume <= 0.0) return 0xFFFFFFFFu.toLong()
        fun channel(shift: Int): Long = (liquids.sumOf {
            ((it.ingredient.colorArgb ushr shift) and 0xFF) * it.ml
        } / volume).roundToLong().coerceIn(0, 255)
        val a = channel(24)
        val r = channel(16)
        val g = channel(8)
        val b = channel(0)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    companion object { const val ICE_MELT_YIELD = 0.70 }
}
