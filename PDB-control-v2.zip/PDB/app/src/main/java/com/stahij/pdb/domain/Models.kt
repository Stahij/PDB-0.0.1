package com.stahij.pdb.domain

enum class IngredientType { SPIRIT, LIQUEUR, JUICE, SYRUP, BITTER, TOPPING, ICE, FRUIT, OTHER }
enum class IngredientRole { IN_DRINK, GARNISH }

data class Ingredient(
    val id: Long,
    val name: String,
    val type: IngredientType,
    val abv: Double,
    val colorArgb: Long,
    val sweetness: Double,
    val sourness: Double,
    val bitterness: Double,
    val version: Int = 1,
)

data class Portion(val ingredient: Ingredient, val ml: Double, val role: IngredientRole = IngredientRole.IN_DRINK)
data class Glass(val id: Long, val name: String, val capacityMl: Int)

data class CocktailResult(
    val liquidMl: Double = 0.0,
    val occupiedMl: Double = 0.0,
    val abv: Double = 0.0,
    val sweetness: Double = 0.0,
    val sourness: Double = 0.0,
    val bitterness: Double = 0.0,
    val strength: Double = 0.0,
    val colorArgb: Long = 0xFFFFFFFFu.toLong(),
)

data class CocktailDraft(
    val glass: Glass,
    val portions: List<Portion> = emptyList(),
    val meltFraction: Double = 0.0,
    val result: CocktailResult = CocktailResult(),
)
