package com.stahij.pdb
import android.app.Application
import dagger.hilt.android.HiltAndroidApp
@HiltAndroidApp class PdbApplication: Application()
