package com.stahij.pdb.data.local

import android.room3.Database
import android.room3.RoomDatabase

@Database(entities = [IngredientEntity::class, RecipeEntity::class, RecipePortionEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ingredientDao(): IngredientDao
    abstract fun recipeDao(): RecipeDao
}
