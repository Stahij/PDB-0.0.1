package com.stahij.pdb.feature.visualization
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.stahij.pdb.R
import com.stahij.pdb.domain.*
import com.stahij.pdb.ui.*
import kotlin.math.roundToInt
@Composable fun VisualizationScreen(onBack:()->Unit,vm:VisualizationViewModel=hiltViewModel()){val d by vm.store.draft.collectAsStateWithLifecycle();val t=tokens(LocalStyle.current);Scaffold(containerColor=t.background){p->Column(Modifier.padding(p).fillMaxSize().padding(16.dp)){TextButton(onBack){Text(stringResource(R.string.back))};Text(d.glass.name,style=MaterialTheme.typography.headlineLarge);GlassCanvas(d,Modifier.fillMaxWidth().height(390.dp));FlavorSignature(d.result,Modifier.fillMaxWidth().height(180.dp));Text("ABV ${"%.1f".format(d.result.abv)}% · ${d.result.liquidMl.roundToInt()} ml")}}}
@Composable fun GlassCanvas(d:CocktailDraft,modifier:Modifier){val description=stringResource(R.string.glass_visualization_description);val t=tokens(LocalStyle.current);val style=LocalStyle.current;Canvas(modifier.semantics{contentDescription=description}){val w=size.width;val h=size.height;val path=Path();val l=w*.22f;val r=w*.78f;val top=h*.1f;val bottom=h*.9f;when(d.glass.name){"Highball"->{path.moveTo(w*.3f,top);path.lineTo(w*.32f,bottom);path.lineTo(w*.68f,bottom);path.lineTo(w*.7f,top)};"Martini"->{path.moveTo(w*.12f,top);path.lineTo(w*.5f,h*.48f);path.lineTo(w*.88f,top);path.close()};"Coupe"->{path.moveTo(w*.18f,top);path.quadraticTo(w*.25f,h*.43f,w*.5f,h*.43f);path.quadraticTo(w*.75f,h*.43f,w*.82f,top);path.close()};"Shot"->{path.moveTo(w*.35f,h*.3f);path.lineTo(w*.38f,h*.72f);path.lineTo(w*.62f,h*.72f);path.lineTo(w*.65f,h*.3f);path.close()};else->{path.moveTo(l,top);path.lineTo(l+30,bottom);path.lineTo(r-30,bottom);path.lineTo(r,top);path.close()}};val fill=(d.result.liquidMl/d.glass.capacityMl).toFloat().coerceIn(0f,1f);val y=bottom-(bottom-top)*fill;val color=Color(d.result.colorArgb.toULong());val brush:Brush=if(style==Style.PAPER_LAB) SolidColor(color.copy(alpha=.48f)) else Brush.verticalGradient(listOf(color.copy(alpha=.55f),color.copy(alpha=.92f)));clipPath(path){drawRect(brush,Offset(0f,y),Size(w,bottom-y));val ice=d.portions.filter{it.ingredient.type==IngredientType.ICE}.sumOf{it.ml}*(1-d.meltFraction*.7);repeat((ice/35).roundToInt().coerceIn(0,6)){i->drawRoundRect(t.accent.copy(alpha=.32f),Offset(l+45+(i%2)*70,bottom-65-(i/2)*50),Size(42f,42f),CornerRadius(8f,8f),style=Stroke(2f))}};drawPath(path,if(style==Style.NEO_LAB)t.primary else t.text,style=Stroke(if(style==Style.PAPER_LAB)6f else 4f))}}
