package com.stahij.pdb.ui
import androidx.compose.runtime.*
import com.stahij.pdb.core.navigation.AppNavHost
@Composable fun PdbApp(){var style by remember{mutableStateOf(Style.PREMIUM)};CompositionLocalProvider(LocalSetStyle provides {style=it}){PdbTheme(style){AppNavHost()}}}
