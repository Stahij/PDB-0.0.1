# PDB Cocktail Creator — control package v0.2

Native Android MVP baseline for the first real CI build.

## Implemented
- Kotlin/Compose Material 3, Hilt, Room 3, Navigation Compose, MVVM + StateFlow.
- 50 seed ingredients and 5 glasses.
- ABV, volume, simple 0–10 taste heuristics, color estimate, ice dilution.
- IN_DRINK/GARNISH separation with toggle rather than duplicates.
- Explicit overflow indicator rather than silently pretending the glass fits.
- Flavor Signature with labeled axes.
- Canvas glass visualization clipped to the vessel path.
- Four visual systems: Premium, Neo Lab, Flavor Signature, Paper Lab.
- EN/RU/TR/zh-CN UI resources for the current MVP screens.
- Room entities/DAO/repository and seed initialization.
- Unit tests for ABV, garnish isolation, ice dilution, and seed integrity.
- GitHub Actions workflow for tests, debug APK, and artifact upload.

## Model caveats
Taste values are product heuristics on a 0–10 scale, not laboratory measurements. `strength` is currently derived from ABV and should be calibrated with bartender testing. Color is a volume-weighted ARGB approximation. Ice uses a provisional 0.70 melt-yield coefficient. These parameters require physical validation before making accuracy claims.

## Ingredient data provenance
The current catalog is seed data for software validation. ABV and flavor/color values must not be presented as verified product facts until a source/date validation table is added. Ingredient `version` is persisted in recipe portions so future accepted catalog revisions can preserve historical recipes.

## First CI objective
Get `testDebugUnitTest` and `assembleDebug` green without deleting features or replacing architecture. Dependency/tooling adjustments are allowed when required for AGP 9.1.1 compatibility.

## Deferred from this first-build package
Full recipes library CRUD UI, PNG share card + Android Share Sheet, authentication/cloud/community/moderation/admin UI, screenshot/UI tests, production signing, and sourced ingredient calibration.
