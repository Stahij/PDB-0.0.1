# Claude review remediation — control v0.2

Implemented before second handoff:
- AGP 9 built-in Kotlin: removed `org.jetbrains.kotlin.android`.
- Updated KSP/Hilt baseline for AGP 9 migration guidance.
- Gradle 9.3.1 wrapper configuration and CI bootstrap generation.
- Fixed Float→Double slider conversion.
- Fixed Canvas Color/Brush branch by using a single Brush type.
- Introduced MVVM/StateFlow, repository, Room DAO/entities/database, Hilt bindings, Navigation Compose.
- Renamed domain `Result` → `CocktailResult`.
- Explicit overflow state.
- Garnish is toggleable and cannot accumulate duplicate UI entries.
- Canvas liquid uses `clipPath`.
- Flavor Signature axes are labeled.
- UI strings moved into EN/RU/TR/zh-CN resources for current screens.
- Tests expanded for ice dilution and seed integrity.
- App icon placeholder, ProGuard file, signing-file ignores.
- Canvas visualizations receive accessibility content descriptions.
- Added ingredient data provenance template and documented heuristic limitations.

Still requires real GitHub/Android build verification. Full recipe CRUD UI, sharing, social/cloud/admin, production signing, and screenshot tests remain subsequent MVP work rather than hidden/faked features.
